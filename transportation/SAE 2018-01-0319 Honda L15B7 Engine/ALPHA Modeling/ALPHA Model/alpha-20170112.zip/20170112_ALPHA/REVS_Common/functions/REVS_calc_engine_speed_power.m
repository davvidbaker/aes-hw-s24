function [ power_norm ] = REVS_calc_engine_speed_power( e, speed_radps )
% REVS_calc_engine_speed_power(engine, speed_radps) returns the fraction
% of full engine power available at that speed

power_norm = interp1(e.full_throttle_speed_radps, e.full_throttle_torque_Nm, speed_radps) .* speed_radps / e.max_power_W;

end
