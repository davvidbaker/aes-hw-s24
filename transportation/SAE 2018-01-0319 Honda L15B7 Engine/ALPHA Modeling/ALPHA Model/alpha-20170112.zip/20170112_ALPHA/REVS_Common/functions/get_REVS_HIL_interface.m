function [ out] = get_REVS_HIL_interface( HIL)

out = HIL.interface;

end

