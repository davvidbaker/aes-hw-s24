function [ out] = get_REVS_transmission_gear_strategy_type( transmission)

out = transmission.gear_strategy.type;

end

