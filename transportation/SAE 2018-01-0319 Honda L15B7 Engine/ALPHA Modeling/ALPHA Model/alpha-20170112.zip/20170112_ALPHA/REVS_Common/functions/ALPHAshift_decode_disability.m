function [ dc_struct] = autoshift_decode_disability( dc )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


dc_struct.neutral = (dc >= 265);
dc = mod(dc,256);

dc_struct.shift_parity = (dc >= 128);
dc = mod(dc,128);

dc_struct.skip_shift = (dc >= 64);
dc = mod(dc,64);

dc_struct.downshift_max_speed = (dc >= 32);
dc = mod(dc,32);

dc_struct.upshift_torque_reserve = (dc >= 16);
dc = mod(dc,16);

dc_struct.upshift_min_speed = (dc >= 8);
dc = mod(dc,8);

dc_struct.available_torque = (dc >= 4);
dc = mod(dc,4);

dc_struct.max_speed = (dc >= 2);
dc = mod(dc,2);

dc_struct.min_speed = (dc >= 1);

end

