function [ out] = get_REVS_engine_deac_strategy_type( engine)

out = engine.deac_strategy.type;

end

