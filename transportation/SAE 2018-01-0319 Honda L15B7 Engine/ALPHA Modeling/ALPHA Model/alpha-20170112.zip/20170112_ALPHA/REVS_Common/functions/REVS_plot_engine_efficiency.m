function REVS_plot_engine_efficiency(e, varargin)

REVS_plot_engine(e,'efficiency',varargin{:})
