function [ mpg_results ] = REVS_get_results( results, result_index, phase_num, num_results )
% function [ answer ] = REVS_get_results( results, result_index, phase_num, num_results )
% phase_num == 0 returns total FE_mpg, otherwise returns num_results worth
% of phase_num phase_FE_mpg

mpg_results = zeros(1, num_results);

for i = 0:num_results-1
    %    [results(A).result.phase_FE_mpg(1) results(A+1).result.phase_FE_mpg(1) results(A+2).result.phase_FE_mpg(1)];
    try
        if phase_num > 0
            mpg_results(i+1) = results(result_index + i).result.phase_FE_mpg(phase_num);
        else
            mpg_results(i+1) = results(result_index + i).result.FE_mpg;
        end
    end
end


end

