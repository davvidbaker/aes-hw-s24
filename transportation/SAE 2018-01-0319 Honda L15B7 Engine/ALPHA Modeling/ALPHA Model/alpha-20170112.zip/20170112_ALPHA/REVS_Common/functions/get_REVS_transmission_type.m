function [ out] = get_REVS_transmission_type( transmission)

out = transmission.type;

end

