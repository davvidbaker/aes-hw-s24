function [ out] = get_REVS_HIL_component( HIL)

out = HIL.component;

end

