function [ out] = get_REVS_powertrain_type( REVS)

out = REVS.powertrain_type;

end

