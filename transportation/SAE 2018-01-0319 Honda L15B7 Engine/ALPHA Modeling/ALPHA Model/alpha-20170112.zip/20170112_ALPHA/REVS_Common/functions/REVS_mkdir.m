function [SUCCESS, MESSAGE, MESSAGEID] = REVS_mkdir( dirpath )
% REVS_mkdir attempts to make a directory, without "directory already
% exists" warnings

warning off % ignore "directory already exists" warnings...

[SUCCESS, MESSAGE, MESSAGEID] = mkdir(dirpath);

if ~SUCCESS
    error('%s %s', MESSAGE, dirpath);
end

warning on

end
