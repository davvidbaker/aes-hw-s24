function [ out] = get_REVS_engine_model_type( engine)

out = engine.model_type;

end

