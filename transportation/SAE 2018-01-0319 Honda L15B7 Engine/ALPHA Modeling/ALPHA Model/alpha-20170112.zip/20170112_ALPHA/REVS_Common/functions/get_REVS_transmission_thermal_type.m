function [ out] = get_REVS_transmission_thermal_type( transmission)

out = transmission.thermal.type;

end

