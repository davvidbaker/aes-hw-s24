function [ val ] = REVS_class_default( parameter, default_val, disable_default )
% REVS_class_default
% return default value if parameter not provided

if nargin > 2 && disable_default
	val = parameter;
elseif isempty(parameter) 
	val = default_val;
elseif all(isnan(parameter))
	val = default_val;
else
	val = parameter;
end

end

