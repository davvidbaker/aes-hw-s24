function [ col_out ] = mat2colByIdx( A, B )

col_out = A( sub2ind( size(A), (1:size(A,1))', B ) );