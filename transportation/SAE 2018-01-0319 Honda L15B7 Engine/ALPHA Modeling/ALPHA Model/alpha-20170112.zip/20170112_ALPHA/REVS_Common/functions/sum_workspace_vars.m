function var_sum = sum_workspace_vars(vars)
    var_sum = 0;
    for i = 1:length(vars)
        var_sum = var_sum + evalin('caller', vars{i});
    end

end