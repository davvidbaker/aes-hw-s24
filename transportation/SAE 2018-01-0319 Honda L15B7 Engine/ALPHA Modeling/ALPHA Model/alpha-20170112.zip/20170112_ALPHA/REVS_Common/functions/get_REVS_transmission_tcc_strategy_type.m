function [ out] = get_REVS_transmission_tcc_strategy_type( transmission)

out = transmission.tcc_strategy.type;

end

