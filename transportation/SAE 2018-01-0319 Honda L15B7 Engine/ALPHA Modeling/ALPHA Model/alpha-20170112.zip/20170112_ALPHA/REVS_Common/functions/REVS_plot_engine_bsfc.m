function REVS_plot_engine_bsfc(e, varargin)

REVS_plot_engine(e,'BSFC',varargin{:})
