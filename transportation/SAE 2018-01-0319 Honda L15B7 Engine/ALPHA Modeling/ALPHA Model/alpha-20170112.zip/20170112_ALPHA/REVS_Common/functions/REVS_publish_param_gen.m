function REVS_publish_param_gen( gen_file, varargin )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

close all
evalc('run( gen_file )');

warn_stat = warning('off','all');

pub_file = [strrep(gen_file,'.m',''),'_pub.m'];
pub_file_str = readfile( gen_file);



for i = 1:numel(varargin)
	clear(varargin{i});
	pub_file_str = sprintf( '%s\n\n%%%% Generated %s: \n\n%s\n',pub_file_str, varargin{i}, readfile(varargin{i}) );
end


fid = fopen( pub_file , 'w+');
fprintf( fid,'%s', pub_file_str );
fclose(fid);


gen_pub = publish(pub_file,'format','doc','figureSnapMethod','print');

% delete(pub_file);

end


function str = readfile( file_path )

fid = fopen( file_path , 'r+');
str = fread( fid,inf,'char');
fclose(fid);

end 

