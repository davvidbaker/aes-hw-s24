classdef enum_speed_source < Simulink.IntEnumType
    enumeration
        vehicle_speed_mph(0)
        gearbox_output_rpm(1)
        vehicle_wheel_rpm(2)
		engine_speed_rpm(3)
        gearbox_input_rpm(4)
        gearbox_input_radps(5)
        gearbox_output_radps(6)
        engine_speed_radps(7)
        vehicle_speed_mps(8)
        vehicle_speed_kmh(9)
    end

end
