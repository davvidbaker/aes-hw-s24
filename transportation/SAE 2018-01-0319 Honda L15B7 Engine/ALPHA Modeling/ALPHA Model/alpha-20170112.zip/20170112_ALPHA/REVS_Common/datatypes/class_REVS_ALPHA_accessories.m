classdef class_REVS_ALPHA_accessories
	%REVS_ALPHA_electric
	%   ALPHA Electric & Accessory description class. Contains definitions
	%	for starter, alternator, battery & air conditioning and other
	%	accessory losses
	
	properties
        
        name = '';
		generic_loss    = class_REVS_accessory_load;
		fan             = class_REVS_accessory_load;
		power_steering  = class_REVS_accessory_load;
		air_conditioner = class_REVS_accessory_load;
		
	end
	
	
end

