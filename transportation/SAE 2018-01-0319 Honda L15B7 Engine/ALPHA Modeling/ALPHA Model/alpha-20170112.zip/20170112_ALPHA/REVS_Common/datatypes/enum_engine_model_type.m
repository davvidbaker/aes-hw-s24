classdef enum_engine_model_type < Simulink.IntEnumType
    enumeration
        legacy(0)
        current(1)
    end
    
end


