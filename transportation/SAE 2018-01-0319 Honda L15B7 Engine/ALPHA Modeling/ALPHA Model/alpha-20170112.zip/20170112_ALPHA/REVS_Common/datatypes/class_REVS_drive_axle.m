classdef class_REVS_drive_axle
	%class_REVS_drive_axle
	%   
	
	properties
		brake = struct(	'max_torque_Nm',[],...				% Axle brakes properties
						'proportion_norm',1.0,...
						'inertia_kgm2',0.0);											
		tire = struct(	'radius_m',[],...					% Axle tire properties
						'rolling_resistance_coefficient',0,...
						'vehicle_weight_norm',1.0, ...
						'wheel_slip_torque_Nm',[], ...
						'inertia_kgm2',0.0);		
		final_drive = struct(	'gear_ratio',[],...
								'efficiency_norm',[],...
								'inertia_kgm2',[] );																										% Axle final drive ratio reduction
		
	end
	
	methods
		
		
	end
	
end

