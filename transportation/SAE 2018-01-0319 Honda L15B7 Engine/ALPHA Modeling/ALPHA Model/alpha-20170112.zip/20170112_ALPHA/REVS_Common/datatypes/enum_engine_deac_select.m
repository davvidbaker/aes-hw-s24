classdef enum_engine_deac_select < Simulink.IntEnumType
    enumeration
        constant(0)
        dynamic_lookup(1)
		dynamic_criteria(2)
    end
    
end
