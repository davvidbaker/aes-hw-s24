classdef class_REVS_tableshift
    %class_tableshift
    
    properties        
        upshift_delay_secs    = [];    
        downshift_delay_secs  = [];  
    
        shift_speed_source = enum_speed_source.gearbox_output_rpm;
        shift_load_source = enum_load_source.engine_load_norm;  
    
        % Define Transmission Shifting Schedule
        % ... upshifting schedule (transmission output speed in RPM)
        upshift_map_load = [];
        upshift_map_speed   = []';    % from Ricardo

        % ... downshifting schedule (transmission output speed in RPM)
        transmission.tableshift.downshift_map_load = [];
        transmission.tableshift.downshift_map_speed = []'; 
    end
        
    
    methods
    end
    
end

