classdef enum_transmission_thermal_type < Simulink.IntEnumType
    enumeration
        none(0)
        constant_temperature(1)
        gradient_temperature(2)
        time_lookup(3)
        thermal_model(4)
    end
    
end
