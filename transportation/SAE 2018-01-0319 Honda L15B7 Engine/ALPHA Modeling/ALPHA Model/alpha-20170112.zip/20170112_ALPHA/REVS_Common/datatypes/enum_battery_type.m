classdef enum_battery_type < Simulink.IntEnumType
    enumeration
        lead_acid(1)
        LiIonPolymer(2)
        LiFePO4_Energy(3)
        LiFePO4_Power(4)
        NiMH(5)
    end
    
end
