classdef enum_driveline_type < Simulink.IntEnumType
    enumeration
        one_axle_drive(0)
        C8_tractor_trailer(1)
        C7_tractor_trailer(2)
        C8_vocational(3)
        C2b7_vocational(4)
        C7_tractor_short_trailer(5)
        C8_tractor_short_trailer(6)  %jlb 2015-01-21
    end
    
end
