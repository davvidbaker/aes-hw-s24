classdef class_REVS_constant_accessory
	%UNTITLED5 Summary of this class goes here
	%   Detailed explanation goes here
	
	properties
		power_W;				% Accessory constant loss power [W]
		inertia_kgm2 = 0;		% Accessory rotational inertia [km*m^2]	
	end
	
	methods
	end
	
end

