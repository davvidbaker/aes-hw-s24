classdef enum_key_position < Simulink.IntEnumType
    enumeration
        key_off(0)
        key_accessory(1)
        key_run(2)
    end
    
end
