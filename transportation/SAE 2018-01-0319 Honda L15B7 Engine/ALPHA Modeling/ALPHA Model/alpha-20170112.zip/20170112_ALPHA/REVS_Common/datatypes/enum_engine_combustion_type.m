classdef enum_engine_combustion_type < Simulink.IntEnumType
    enumeration
        compression_ignition(0)
        spark_ignition(1)
    end
    
end
