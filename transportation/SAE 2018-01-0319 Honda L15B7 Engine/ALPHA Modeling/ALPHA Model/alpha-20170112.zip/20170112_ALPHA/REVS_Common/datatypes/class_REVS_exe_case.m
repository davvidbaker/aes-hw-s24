classdef class_REVS_exe_case < class_REVS_sim_case
	%UNTITLED4 Summary of this class goes here
	%   Detailed explanation goes here
	
	properties
	end
	
	methods
	end
	
end

