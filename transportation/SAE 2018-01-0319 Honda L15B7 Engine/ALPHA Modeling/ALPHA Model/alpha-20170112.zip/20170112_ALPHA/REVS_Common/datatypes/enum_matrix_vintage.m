classdef enum_matrix_vintage < Simulink.IntEnumType
    enumeration
        no_vintage(0)
        past(1)
        present(2)
        future(3)
        
    end
    
end
