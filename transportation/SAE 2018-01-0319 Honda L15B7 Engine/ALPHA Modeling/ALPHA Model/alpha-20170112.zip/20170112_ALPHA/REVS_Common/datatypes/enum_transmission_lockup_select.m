classdef enum_transmission_lockup_select < Simulink.IntEnumType
    enumeration
        table_lockup(0)
        lockup_rules_speed_select(1)
        lockup_rules_dynamic_expression(2)
		uber_dynamic(3)
        uber_dynamic_3state(4)
        external_lockup(5)
    end
    
    methods
        % overloading mat2str allows us to store enums in database without
        % special treatment
        function [str] = mat2str(obj)
			class_str = class(obj);
 			[enums,strs] = enumeration(class_str);
			idx = (enums == obj);
			str = [class_str,'.',strs{idx}];
        end   
     end

end
