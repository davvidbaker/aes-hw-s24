classdef class_REVS_documentation
    %documentation class for REVS components
    
    properties
        name;
        file_version;
        manufacturer;
        source;
        CBI_bool;
        note;
    end
    
    methods
    end
    
end

