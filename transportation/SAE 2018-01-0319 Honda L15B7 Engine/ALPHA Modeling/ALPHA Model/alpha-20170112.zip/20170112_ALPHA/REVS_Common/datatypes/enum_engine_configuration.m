classdef enum_engine_configuration < Simulink.IntEnumType
    enumeration
		I3(3)
        I4(4)		% 
        I5(5)		% 
        I6(6)		% 
        V6(7)		% 
        V8(8)		% 
        V10(10)		% 
    end
    
end
