classdef enum_transmission_gear_select < Simulink.IntEnumType
    enumeration
        none(0)
        autoshift(1)
        tableshift(3)
        tableshift_skipshift(4)
        externalshift(5)
        autoshift2(6)
        autoshift3(7)
		JRC_polygon(8)
        ALPHAshift(9)
		ALPHAshift_CVT(10)
        externalshift_CVT(11)
        subarushift_CVT(12)
    end
    
end
