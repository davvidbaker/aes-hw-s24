classdef enum_load_source < Simulink.IntEnumType
    enumeration
        driver_acl_norm(0)
        engine_load_norm(1)
        driver_acl_pct(2)
        engine_load_pct(3)
		engine_load_Nm(4)
    end
    
end
