classdef enum_model_type < Simulink.IntEnumType
    enumeration
        GEM(0)
        ALPHA(1)
        REVS(2)
    end
    
end
