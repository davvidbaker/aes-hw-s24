classdef class_REVS_passive_axle
	% class_REVS_passive_axle
	%   
	
	properties
		brake;
		tire;
		
	end
	
	methods
	end
	
end

