classdef class_REVS_dynamic_lookup_axis
	%UNTITLED3 Summary of this class goes here
	%   Detailed explanation goes here
	
	properties
		signal@char = '';
		breakpoints@double vector = [];
		extrapolate_above@logical scalar = false;
		extrapolate_below@logical scalar = false;
		
	end
	
	methods
	end
	
end

