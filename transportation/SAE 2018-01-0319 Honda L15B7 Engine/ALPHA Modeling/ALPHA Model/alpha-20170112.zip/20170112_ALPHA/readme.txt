Instructions for running ALPHA, Tech Walk Edition (2017.01.10):

For more information about ALPHA visit: 
	https://www.epa.gov/regulations-emissions-vehicles-and-engines/advanced-light-duty-powertrain-and-hybrid-analysis-alpha

System Requirements:
	Matlab/Simulink with StateFlow 2016b, may also work with later releases after library/model up-conversions.
	Also required is a compiler, for compiling the StateFlow code, see
		www.mathworks.com/support/compilers/R2016b/index.html
	
1) Launch Matlab and add REVS_Common and its subfolders to your Matlab path (from the Matlab console, select "Set Path" from the "HOME" tab of the Matlab window,
	then select "Add with Subfolders..." and browse to REVS_Common)

2) Change your Matlab working directory to (for example)
	20170112_ALPHA\Ford Tech Walk\publish_fusion_matrix
    using the appropriate file path for your system.

	Run the example script:
	>> sample_run;

    The Matlab Command Window will display an energy audit of the simulation once it has completed.
	
    The cold-corrected FTP and weighted-combined city-highway results will be calculated, and fuel consumption details will be
    displayed.

    A series of results will be displayed in the Matlab console window.  The include drive quality statistics for each phase
    of the drive cycle and a set of fuel economy and GHG emissions results, including the weighted-combined results.

	In the Matlab workspace, after simulation, the following variables will hold simulation trace data: datalog, audit, result, model_data
    The model_data variable holds many signals of interest, pulled from the datalog and audit structures, and may be explored as desired.

    As a convenience, some signals of common interest may be plotted using the following command: 
        >> REVS_CVM_DOR({},model_data,'engine',engine,'time_range',[0 2640]);

Notes:
	1) To run a different sample case, edit line 7 of sample_run.m

Background:
	The REVS_Common folder contains the core models and libraries used by ALPHA as well as helper functions
	and various scripts for processing data before and after simulation.  The libraries here are a subset of the complete
	package used for our in-house modeling efforts so it's possible one may find references to libraries or subroutines that
	are not present, e.g. hybrid or electric vehicles or alternative transmission technologies which are not part of this ALPHA release.

	REVS_Common\REVS_VM.slx is the Simulink model file.

	Vehicle and component parameters are stored in the sample workspace files, which are provided in .mat and .txt form.
    	The plaintext form of the workspace is an m-file format but will not be runnable, it's only purpose is to provide a look
    	at the complete workspace in a human-readable form that does not required Matlab or Simulink.

	Engine descriptions:
	engine_2010_light_duty_truck_NA_CCP is based on the 5.4L V8 NA engine used in the original 2025 LD GHG rulemaking
	I4_2L5_GDI_VVT 			is based on the 2013 Chevy Malibu 2.5L engine
	I4_1L17_GDI_TURB24_VVT_CEGR	is based on a 24-bar turbo-downsized 1.17L engine with cooled EGR, adapted from the Ricardo engine used in the original rulemaking
	Ford F150 Ecoboost 2.7l Tier2	is based on EPA benchmarking of a Ford 2.7L EcoBoost engine
	Toyota TNGA 2.5L		is based on publicly available data documenting the Toyota TNGA I4 2.5L NA engine
	Honda L15B7 1.5L		is based on publicly available data documenting the 2016 Honda L15B7 I4 1.5L Turbo engine

	Transmission descriptions:
	TRX11 	is based on the GM6T40 from the 2013 Chevy Malibu
	TRX21	is based on the 2014 Chrysler/Fiat 845RE
	TRX22 	is based on the 2014 Chrysler/Fiat 845RE with reduced losses and extended span

Disclaimer:
	ALPHA is under active development and this release represents the state of the package at a particular
	point in time, it is subject to change without notice.  Sample input and output files are provided for reference only and
	cannot be processed by the peer review package and may not represent the production file formats.

