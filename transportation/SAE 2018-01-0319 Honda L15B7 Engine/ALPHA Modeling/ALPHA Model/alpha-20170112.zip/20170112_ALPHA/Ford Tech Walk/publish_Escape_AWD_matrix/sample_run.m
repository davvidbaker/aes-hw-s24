%% PRECONDITION: make sure REVS_Common and its subfolders are in your Matlab path

%% clear the workspace
clear

%% load a workspace
load('config_1_workspace.mat');

%% open the model if you want to see it run
open REVS_VM;

%% start the simulation
warning('off','Simulink:blocks:BusSelectorOutSignalNameUpdate');

sim(REVS.current_model);

%% run postprocess
matrix_publish_postprocess;

%% generate some plots, if desired, see REVS_CVM_DOR help for more options
REVS_DOR_CVM({},model_data,'engine',engine,'time_range',[0 2640]);
